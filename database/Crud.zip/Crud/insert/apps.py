from django.apps import AppConfig


class InsertConfig(AppConfig):
    name = 'insert'
